% Startup script for sm_water_powered_lift.slx
% Copyright 2017-2024 The MathWorks, Inc.

sm_water_powered_lift_param

sm_water_powered_lift

